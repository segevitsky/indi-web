import"./assets/modulepreload-polyfill-YP0FEG5d.js";chrome.devtools.panels.create("Indi Mapper","","/panel/index.html",e=>{});
